'use strict';
const $ = (id) => document.getElementById(id);
const keyInput = $('key');
const form = $('connectForm');
const connectPanel = $('connectPanel');
const error = $('loginError');
const network = $('network');
const connectionText = $('connectionText');
const pulse = $('pulse');
const screen = $('screen');
const empty = $('empty');
const stats = $('frameStats');
let session = '';
let connected = false;
let currentUrl = '';
let gestureStart = null;
let lastImageTime = 0;
let updateTimer = null;
let frameEtag = '';
let frameFailures = 0;
const remoteText = $('remoteText');
const textStatus = $('textStatus');

function render() {
  network.textContent = connected ? 'Online' : 'Offline';
  network.className = 'tag ' + (connected ? 'on' : 'off');
  connectionText.textContent = connected ? 'Redmi terhubung' : 'Belum terhubung';
  pulse.classList.toggle('active', connected);
  for (const b of document.querySelectorAll('[data-action]')) b.disabled = !connected;
  $('sendText').disabled = !connected;
}
function stop() {
  connected = false; session = ''; gestureStart = null;
  if (updateTimer) clearTimeout(updateTimer);
  updateTimer = null;
  frameEtag = ''; frameFailures = 0;
  textStatus.textContent = '';
  if (currentUrl) { URL.revokeObjectURL(currentUrl); currentUrl = ''; }
  screen.removeAttribute('src'); screen.hidden = true; empty.hidden = false;
  connectPanel.hidden = false;
  render();
}
async function loadFrame() {
  if (!connected) return;
  let interval = 350;
  try {
    const headers = { 'X-Arunika-Session': session };
    if (frameEtag) headers['If-None-Match'] = frameEtag;
    const result = await fetch('/frame', { headers, cache: 'no-store' });
    if (!connected) return;
    if (result.status === 401) { error.textContent = 'Sesi kedaluwarsa. Silakan login kembali.'; stop(); return; }
    if (result.status === 304) {
      frameFailures = 0;
    } else if (result.ok) {
      const blob = await result.blob();
      if (!connected) return;
      const url = URL.createObjectURL(blob);
      const oldUrl = currentUrl;
      screen.onload = () => { if (oldUrl) URL.revokeObjectURL(oldUrl); };
      currentUrl = url;
      screen.src = url;
      screen.hidden = false; empty.hidden = true;
      frameEtag = result.headers.get('ETag') || '';
      lastImageTime = Date.now();
      frameFailures = 0;
      stats.textContent = 'Mode cepat aktif • ' + new Date().toLocaleTimeString('id-ID');
    } else if (result.status === 423 || result.status === 425) {
      interval = 900;
      frameEtag = '';
      if (currentUrl) { URL.revokeObjectURL(currentUrl); currentUrl = ''; }
      screen.removeAttribute('src'); screen.hidden = true; empty.hidden = false;
      stats.textContent = result.status === 423
        ? 'Redmi terkunci. Coba Bangunkan layar. Jika meminta PIN/pola, buka kunci langsung di Redmi.'
        : 'Layar Redmi mati. Tekan tombol Bangunkan layar.';
      frameFailures = 0;
    } else if (result.status === 503) {
      interval = 650;
    } else {
      throw new Error('Response: ' + result.status);
    }
  } catch (_) {
    frameFailures++;
    interval = Math.min(5000, 600 * Math.pow(1.7, Math.min(frameFailures, 4)));
    stats.textContent = 'Koneksi terganggu; mencoba tersambung kembali';
  }
  if (connected) updateTimer = setTimeout(loadFrame, interval);
}
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const password = keyInput.value;
  if (password.length < 12) { error.textContent = 'Password minimal 12 karakter.'; return; }
  $('connectBtn').disabled = true;
  error.textContent = '';
  try {
    const res = await fetch('/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password }), cache: 'no-store'
    });
    if (!res.ok) { error.textContent = 'Password salah atau login dibatasi sementara.'; return; }
    const reply = await res.json();
    if (!/^[a-f0-9]{64}$/.test(reply.session || '')) throw new Error('Unexpected session');
    session = reply.session;
    keyInput.value = '';
    connected = true;
    connectPanel.hidden = true;
    render();
    loadFrame();
  } catch (_) { error.textContent = 'Tidak dapat login. Periksa Tailscale dan Redmi.'; }
  finally { $('connectBtn').disabled = false; }
});
$('disconnect').addEventListener('click', () => {
  if (session) fetch('/logout', { method:'POST', headers:{'X-Arunika-Session': session} }).catch(()=>{});
  stop(); keyInput.value = '';
});
async function sendAction(action, values = {}) {
  if (!connected) return;
  try {
    const result = await fetch('/action', {
      method: 'POST', headers: { 'X-Arunika-Session': session, 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...values }), cache: 'no-store'
    });
    if (result.status === 401) { error.textContent = 'Sesi tidak berlaku, login kembali'; stop(); }
  } catch (_) { stats.textContent = 'Gagal mengirim perintah, periksa Tailscale'; }
}
$('typingForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!connected) { textStatus.textContent = 'Hubungkan Redmi terlebih dahulu.'; return; }
  const value = remoteText.value;
  if (!value.trim()) { textStatus.textContent = 'Tulis teks terlebih dahulu.'; return; }
  const mode = $('textMode').value;
  $('sendText').disabled = true;
  textStatus.textContent = 'Mengirim teks...';
  try {
    const res = await fetch('/action', {
      method: 'POST',
      headers: { 'X-Arunika-Session': session, 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'text', text: value, mode }),
      cache: 'no-store'
    });
    if (!res.ok) throw new Error(String(res.status));
    textStatus.textContent = 'Perintah terkirim. Lihat hasilnya pada layar Redmi.';
  } catch (_) {
    textStatus.textContent = 'Gagal mengirim teks. Periksa koneksi dan sesi login.';
  } finally {
    $('sendText').disabled = !connected;
  }
});
for (const b of document.querySelectorAll('[data-action]')) b.addEventListener('click', () => sendAction(b.dataset.action));
function point(ev) {
  const rect = screen.getBoundingClientRect();
  if (!rect.width || !rect.height) return null;
  return {
    x: Math.max(0, Math.min(1, (ev.clientX - rect.left) / rect.width)),
    y: Math.max(0, Math.min(1, (ev.clientY - rect.top) / rect.height))
  };
}
screen.addEventListener('pointerdown', (ev) => {
  if (!connected || ev.button > 0) return;
  ev.preventDefault(); screen.setPointerCapture(ev.pointerId);
  gestureStart = { p: point(ev), id: ev.pointerId };
});
screen.addEventListener('pointerup', (ev) => {
  if (!gestureStart || ev.pointerId !== gestureStart.id) return;
  ev.preventDefault();
  const e = point(ev); const start = gestureStart; gestureStart = null;
  if (!e || !start.p) return;
  const diff = Math.hypot(e.x - start.p.x, e.y - start.p.y);
  if (diff > 0.022) sendAction('swipe', { ...start.p, x2:e.x, y2:e.y });
  else sendAction('tap', start.p);
});
screen.addEventListener('pointercancel', () => { gestureStart = null; });
render();
