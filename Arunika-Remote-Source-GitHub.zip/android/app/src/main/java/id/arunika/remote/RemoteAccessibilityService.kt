package id.arunika.remote

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.KeyguardManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Point
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Bundle
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/** Explicitly enabled by the owner in Android Accessibility Settings. */
class RemoteAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: RemoteAccessibilityService? = null
            private set
        private const val CHANNEL = "arunika_remote_active"
        private const val NOTIF = 101
    }
    @Volatile var stateLabel = "Memulai ..."
        private set
    @Volatile var serverAddress = ""
        private set
    data class Frame(val bytes: ByteArray, val etag: String)
    @Volatile private var lastImage: Frame? = null
    private var frameVersion = 0L
    private val frameSession = java.util.UUID.randomUUID().toString()
    @Volatile private var lastViewerAt = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var server: PrivateHttpServer? = null
    private var active = false
    private var screenshotBusy = false
    private var lastCaptureStarted = 0L
    private var wasViewing = false
    private val monitor = object : Runnable {
        override fun run() {
            if (!active) return
            val tailIp = RemoteConfig.tailscaleIp()?.hostAddress
            if (tailIp.orEmpty() != serverAddress) startOrRefreshServer()
            val isViewing = System.currentTimeMillis() - lastViewerAt < 8000
            if (isViewing != wasViewing) { wasViewing = isViewing; updateNotification() }
            handler.postDelayed(this, 4500)
        }
    }
    private val frameLoop = object : Runnable {
        override fun run() {
            if (!active) return
            if (isScreenLocked() || !isScreenInteractive()) lastImage = null
            else if (server != null && System.currentTimeMillis() - lastViewerAt < 8000 && !screenshotBusy) captureFrame()
            handler.postDelayed(this, 800)
        }
    }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this; applySettings() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean {
        stopRemote(); if (instance === this) instance = null
        return super.onUnbind(intent)
    }
    override fun onDestroy() {
        stopRemote(); if (instance === this) instance = null
        worker.shutdown(); super.onDestroy()
    }

    fun applySettings() {
        handler.post {
            if (!RemoteConfig.enabled(this) || !RemoteConfig.hasPassword(this)) { stopRemote(); return@post }
            val notifications = getSystemService(NotificationManager::class.java)
            if (!notifications.areNotificationsEnabled()) {
                stopRemote(); stateLabel = "Aktifkan izin notifikasi"; return@post
            }
            if (active) { startOrRefreshServer(); return@post }
            active = true
            startOrRefreshServer()
            handler.post(monitor)
            handler.post(frameLoop)
        }
    }

    private fun startOrRefreshServer() {
        server?.stop(); server = null; serverAddress = ""; lastImage = null
        val ip = RemoteConfig.tailscaleIp()
        if (!active) return
        if (ip == null) {
            stateLabel = "Menunggu Tailscale aktif"
        } else {
            try {
                server = PrivateHttpServer(this, ip).also { it.start() }
                serverAddress = ip.hostAddress ?: ""
                stateLabel = "Siap • http://$serverAddress:${PrivateHttpServer.PORT}"
            } catch (_: Exception) { stateLabel = "Gagal membuka layanan lokal" }
        }
        updateNotification()
    }

    private fun stopRemote() {
        active = false
        handler.removeCallbacks(frameLoop); handler.removeCallbacks(monitor)
        server?.stop(); server = null; serverAddress = ""
        lastImage = null; lastViewerAt = 0
        wasViewing = false; screenshotBusy = false
        stateLabel = "Nonaktif"
        getSystemService(NotificationManager::class.java).cancel(NOTIF)
    }

    fun recordViewer() {
        lastViewerAt = System.currentTimeMillis()
        // A newly connected viewer should not wait a full capture interval.
        if (lastImage == null && !screenshotBusy && active) handler.post {
            if (active && !screenshotBusy && lastImage == null &&
                System.currentTimeMillis() - lastCaptureStarted >= 600) captureFrame()
        }
    }
    fun latestFrame(): Frame? = lastImage

    fun isScreenLocked(): Boolean =
        (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked

    fun isScreenInteractive(): Boolean =
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (power.isInteractive) return
        // A short wake request only displays the standard Android lock screen.
        // This never dismisses PIN, password, pattern, or biometric protection.
        val wake = power.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "Arunika:WakeScreen"
        )
        wake.acquire(2_000L)
    }

    fun validAction(data: JSONObject): Boolean {
        return when (data.optString("action")) {
            "back", "home", "recents", "notifications", "wake" -> true
            "text" -> {
                val value = data.optString("text", "")
                val mode = data.optString("mode", "replace")
                value.isNotBlank() && value.length <= 1000 && mode in listOf("replace", "append")
            }
            "tap", "swipe" -> {
                val x = data.optDouble("x", Double.NaN)
                val y = data.optDouble("y", Double.NaN)
                val isSwipe = data.optString("action") == "swipe"
                val x2 = data.optDouble("x2", Double.NaN)
                val y2 = data.optDouble("y2", Double.NaN)
                x.isFinite() && y.isFinite() && x in 0.0..1.0 && y in 0.0..1.0 &&
                    (!isSwipe || (x2.isFinite() && y2.isFinite() && x2 in 0.0..1.0 && y2 in 0.0..1.0))
            }
            else -> false
        }
    }

    fun performRemoteAction(data: JSONObject) {
        if (!active || !validAction(data)) return
        if (data.optString("action") == "wake") { wakeScreen(); return }
        // Respect lock screen: do not dispatch gestures or text while locked.
        if (isScreenLocked() || !isScreenInteractive()) return
        when (data.optString("action")) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "text" -> pasteToFocusedInput(data.optString("text"), data.optString("mode", "replace"))
            "tap", "swipe" -> {
                val point = Point()
                @Suppress("DEPRECATION")
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealSize(point)
                val w = max(1, point.x - 1).toFloat()
                val h = max(1, point.y - 1).toFloat()
                val x = data.optDouble("x")
                val y = data.optDouble("y")
                val gesture = Path().apply {
                    moveTo((x * w).toFloat(), (y * h).toFloat())
                    if (data.optString("action") == "swipe")
                        lineTo((data.optDouble("x2") * w).toFloat(), (data.optDouble("y2") * h).toFloat())
                }
                val time = if (data.optString("action") == "tap") 90L else 420L
                dispatchGesture(GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(gesture, 0, time)).build(), null, null)
            }
        }
    }

    private fun pasteToFocusedInput(value: String, mode: String) {
        // Only modify the editable field explicitly focused by the owner.
        // Never attempt to read/modify password inputs.
        val root = rootInActiveWindow ?: return
        val focus = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        if (!focus.isEditable || focus.isPassword) return
        val result = if (mode == "append") {
            (focus.text?.toString() ?: "") + value
        } else value
        if (result.length > 3000) return
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, result)
        }
        focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun captureFrame() {
        screenshotBusy = true
        lastCaptureStarted = System.currentTimeMillis()
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, java.util.concurrent.Executor { command -> handler.post(command) },
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onFailure(errorCode: Int) { screenshotBusy = false }
                    override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                        worker.execute {
                            val buffer = screenshot.hardwareBuffer
                            try {
                                val bitmap = Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                                    ?: throw IllegalStateException("Buffer not supported")
                                val width = min(480, bitmap.width)
                                val height = max(1, bitmap.height * width / bitmap.width)
                                val scaled = Bitmap.createScaledBitmap(bitmap, width, height, true)
                                val out = ByteArrayOutputStream()
                                try { scaled.compress(Bitmap.CompressFormat.JPEG, 48, out) }
                                finally {
                                    if (scaled !== bitmap) scaled.recycle()
                                    bitmap.recycle()
                                }
                                val encoded = out.toByteArray()
                                // Identical frames need not be sent again over the tailnet.
                                val prior = lastImage
                                if (prior == null || !prior.bytes.contentEquals(encoded)) {
                                    frameVersion++
                                    lastImage = Frame(encoded, "\"frame-$frameSession-$frameVersion\"")
                                }
                            } catch (_: Exception) { /* capture may be blocked on secure screens */ }
                            finally { buffer.close(); handler.post { screenshotBusy = false } }
                        }
                    }
                })
        } catch (_: Exception) { screenshotBusy = false }
    }

    private fun updateNotification() {
        if (!active) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Akses Arunika Remote", NotificationManager.IMPORTANCE_DEFAULT))
        val launch = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getBroadcast(this, 0,
            Intent(this, RemoteStopReceiver::class.java).setAction(RemoteStopReceiver.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentTitle(if (wasViewing) "Arunika Remote • layar sedang diakses" else "Arunika Remote aktif")
            .setContentText(stateLabel)
            .setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(launch)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "HENTIKAN", stop)
            .build()
        try { manager.notify(NOTIF, notification) }
        catch (_: SecurityException) { stopRemote() }
    }
}
