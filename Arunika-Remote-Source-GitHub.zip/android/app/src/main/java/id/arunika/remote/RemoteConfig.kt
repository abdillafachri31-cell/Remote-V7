package id.arunika.remote

import android.content.Context
import android.util.Base64
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Collections
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object RemoteConfig {
    private const val NAME = "arunika_private"
    private const val ACTIVE = "active"
    private const val PASSWORD_SALT = "password_salt_v4"
    private const val PASSWORD_HASH = "password_hash_v4"
    private const val ITERATIONS = 180_000
    private fun prefs(c: Context) = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    @Synchronized fun hasPassword(c: Context): Boolean =
        prefs(c).contains(PASSWORD_SALT) && prefs(c).contains(PASSWORD_HASH)

    private fun encoded(bytes: ByteArray) = Base64.encodeToString(bytes, Base64.NO_WRAP)
    private fun decoded(value: String) = Base64.decode(value, Base64.NO_WRAP)

    private fun pbkdf2(password: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password, salt, ITERATIONS, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }

    @Synchronized fun setPassword(c: Context, password: CharArray) {
        require(password.size in 12..128) { "Password harus 12–128 karakter" }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = pbkdf2(password, salt)
        prefs(c).edit()
            .putString(PASSWORD_SALT, encoded(salt))
            .putString(PASSWORD_HASH, encoded(hash))
            .remove("access_key") // migrate v0.3 random access token
            .apply()
        hash.fill(0)
        salt.fill(0)
    }

    @Synchronized fun checkPassword(c: Context, input: CharArray): Boolean {
        val p = prefs(c)
        val saltString = p.getString(PASSWORD_SALT, null) ?: return false
        val hashString = p.getString(PASSWORD_HASH, null) ?: return false
        return try {
            val expected = decoded(hashString)
            val actual = pbkdf2(input, decoded(saltString))
            val matches = MessageDigest.isEqual(expected, actual)
            expected.fill(0)
            actual.fill(0)
            matches
        } catch (_: Exception) { false }
    }

    fun enabled(c: Context) = prefs(c).getBoolean(ACTIVE, false)
    fun setEnabled(c: Context, value: Boolean) = prefs(c).edit().putBoolean(ACTIVE, value).apply()

    // Restrict server binding to Tailscale's 100.64.0.0/10 interface.
    fun tailscaleIp(): Inet4Address? {
        return try {
            Collections.list(NetworkInterface.getNetworkInterfaces()).asSequence()
                .filter { it.isUp && !it.isLoopback && (it.name.startsWith("tun") || it.name.startsWith("tailscale") || it.name.startsWith("wg")) }
                .flatMap { Collections.list(it.inetAddresses).asSequence() }
                .filterIsInstance<Inet4Address>()
                .firstOrNull {
                    val addr = it.address
                    (addr[0].toInt() and 255) == 100 && ((addr[1].toInt() and 255) in 64..127)
                }
        } catch (_: Exception) { null }
    }
}
