package id.arunika.remote

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale
import java.util.concurrent.Executors

/** Only binds the Tailscale private address. Tailscale encrypts device-to-device traffic. */
class PrivateHttpServer(
    private val service: RemoteAccessibilityService,
    private val address: Inet4Address
) {
    companion object { const val PORT = 18765 }
    private val pool = Executors.newFixedThreadPool(4)
    private var server: ServerSocket? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private val authLock = Any()
    private val sessions = mutableMapOf<String, Long>()
    private var failures = 0
    private var lockedUntil = 0L
    private val random = SecureRandom()
    private val sessionIdleMs = 60L * 60 * 1000
    private val failureLockMs = 15L * 60 * 1000

    fun start() {
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(InetSocketAddress(address, PORT), 12)
        server = s
        running = true
        Thread({
            while (running) {
                try {
                    val sock = s.accept()
                    if (!running) { sock.close(); break }
                    pool.execute { serve(sock) }
                } catch (_: Exception) { if (!running) break }
            }
        }, "Arunika-tailnet-server").apply { isDaemon = true; start() }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        synchronized(authLock) { sessions.clear() }
        pool.shutdownNow()
    }

    private fun readLine(stream: InputStream, cap: Int = 8192): String? {
        val result = ByteArrayOutputStream()
        while (result.size() < cap) {
            val v = stream.read()
            if (v < 0) return null
            if (v == 10) return result.toString("ISO-8859-1").trimEnd('\r')
            result.write(v)
        }
        return null
    }

    private fun response(out: BufferedOutputStream, status: String, contentType: String, data: ByteArray, extraHeaders: String = "") {
        val meta = "HTTP/1.1 $status\r\n" +
            "Content-Type: $contentType\r\nContent-Length: ${data.size}\r\n" +
            "Cache-Control: no-store, max-age=0\r\nX-Content-Type-Options: nosniff\r\n" +
            "X-Frame-Options: DENY\r\nReferrer-Policy: no-referrer\r\n" +
            "Content-Security-Policy: default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' blob:; connect-src 'self'; base-uri 'none'; form-action 'none'\r\n" +
            extraHeaders + "Connection: close\r\n\r\n"
        out.write(meta.toByteArray(StandardCharsets.US_ASCII))
        out.write(data)
        out.flush()
    }
    private fun sendText(out: BufferedOutputStream, status: String, message: String) =
        response(out, status, "text/plain; charset=utf-8", message.toByteArray(StandardCharsets.UTF_8))
    private fun sendJson(out: BufferedOutputStream, status: String, obj: JSONObject) =
        response(out, status, "application/json", obj.toString().toByteArray(StandardCharsets.UTF_8))
    private fun asset(name: String): ByteArray = service.assets.open(name).use { it.readBytes() }
    private fun sessionId(): String = ByteArray(32).also { random.nextBytes(it) }
        .joinToString("") { "%02x".format(it.toInt() and 0xff) }

    private fun isSessionValid(candidate: String): Boolean = synchronized(authLock) {
        if (candidate.length != 64) return@synchronized false
        val now = System.currentTimeMillis()
        sessions.entries.removeAll { now - it.value > sessionIdleMs }
        val match = sessions.keys.firstOrNull {
            MessageDigest.isEqual(it.toByteArray(StandardCharsets.US_ASCII), candidate.toByteArray(StandardCharsets.US_ASCII))
        } ?: return@synchronized false
        sessions[match] = now
        true
    }

    private fun login(password: CharArray): String? {
        synchronized(authLock) { if (System.currentTimeMillis() < lockedUntil) return null }
        val correct = try { RemoteConfig.checkPassword(service, password) } finally { password.fill('\u0000') }
        synchronized(authLock) {
            if (System.currentTimeMillis() < lockedUntil) return null
            if (!correct) {
                failures++
                if (failures >= 5) { lockedUntil = System.currentTimeMillis() + failureLockMs; failures = 0 }
                return null
            }
            failures = 0
            val id = sessionId()
            sessions[id] = System.currentTimeMillis()
            return id
        }
    }

    private fun readBody(input: InputStream, length: Int): ByteArray? {
        if (length !in 1..8192) return null
        val b = ByteArray(length)
        var n = 0
        while (n < length) {
            val got = input.read(b, n, length - n)
            if (got < 0) return null
            n += got
        }
        return b
    }

    private fun serve(socket: Socket) {
        try {
            socket.use { sock ->
                sock.soTimeout = 7000
                val input = BufferedInputStream(sock.getInputStream())
                val output = BufferedOutputStream(sock.getOutputStream())
                val head = readLine(input) ?: return
                val parts = head.split(" ")
                if (parts.size != 3 || parts[2] != "HTTP/1.1") {
                    sendText(output, "400 Bad Request", "Invalid request"); return
                }
                val method = parts[0]
                val path = parts[1]
                var length = 0
                var session = ""
                var ifNoneMatch = ""
                var total = 0
                var foundHeaderEnd = false
                while (total < 8192) {
                    val line = readLine(input) ?: break
                    total += line.length + 2
                    if (line.isEmpty()) { foundHeaderEnd = true; break }
                    val colon = line.indexOf(':')
                    if (colon > 0) {
                        val name = line.substring(0, colon).trim().lowercase(Locale.ROOT)
                        val value = line.substring(colon + 1).trim()
                        if (name == "x-arunika-session") session = value
                        if (name == "if-none-match") ifNoneMatch = value
                        if (name == "content-length") length = value.toIntOrNull() ?: -1
                    }
                }
                if (!foundHeaderEnd || length !in 0..8192) {
                    sendText(output, "400 Bad Request", "Invalid headers"); return
                }
                if (!running) { sendText(output, "503 Service Unavailable", "Remote inactive"); return }
                if (method == "GET" && path in setOf("/", "/index.html", "/style.css", "/app.js")) {
                    val resource = if (path == "/") "index.html" else path.drop(1)
                    val mime = if (resource.endsWith(".js")) "text/javascript" else if (resource.endsWith(".css")) "text/css" else "text/html"
                    response(output, "200 OK", "$mime; charset=utf-8", asset(resource)); return
                }
                if (method == "POST" && path == "/login") {
                    val bytes = readBody(input, length)
                    val pw = try {
                        if (bytes == null) null else JSONObject(String(bytes, StandardCharsets.UTF_8)).optString("password", "")
                    } catch (_: Exception) { null }
                    if (pw.isNullOrEmpty() || pw.length > 128) { sendText(output, "400 Bad Request", "Invalid login"); return }
                    val id = login(pw.toCharArray())
                    if (id == null) sendText(output, "401 Unauthorized", "Password salah atau login dibatasi sementara")
                    else sendJson(output, "200 OK", JSONObject().put("session", id))
                    return
                }
                if (!isSessionValid(session)) { sendText(output, "401 Unauthorized", "Sesi habis. Login kembali."); return }
                when {
                    method == "GET" && path == "/frame" -> {
                        service.recordViewer()
                        if (service.isScreenLocked()) { sendText(output, "423 Locked", "Redmi sedang terkunci"); return }
                        if (!service.isScreenInteractive()) { sendText(output, "425 Too Early", "Layar mati; tekan Bangunkan Layar"); return }
                        val frame = service.latestFrame()
                        if (frame == null) sendText(output, "503 Service Unavailable", "Menunggu tampilan layar")
                        else if (ifNoneMatch == frame.etag)
                            response(output, "304 Not Modified", "image/jpeg", byteArrayOf(), "ETag: ${frame.etag}\r\n")
                        else response(output, "200 OK", "image/jpeg", frame.bytes, "ETag: ${frame.etag}\r\n")
                    }
                    method == "POST" && path == "/action" -> {
                        val bytes = readBody(input, length)
                        val payload = try { if (bytes == null) null else JSONObject(String(bytes, StandardCharsets.UTF_8)) } catch (_: Exception) { null }
                        if (payload == null || !service.validAction(payload)) { sendText(output, "400 Bad Request", "Action invalid"); return }
                        main.post { if (running) service.performRemoteAction(payload) }
                        sendJson(output, "200 OK", JSONObject().put("ok", true))
                    }
                    method == "POST" && path == "/logout" -> {
                        synchronized(authLock) { sessions.remove(session) }
                        sendJson(output, "200 OK", JSONObject().put("ok", true))
                    }
                    else -> sendText(output, "404 Not Found", "Not found")
                }
            }
        } catch (_: Exception) { /* interrupted socket, client timeout */ }
    }
}
