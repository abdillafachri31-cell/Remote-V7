'use strict';
// Dependency-free smoke tests for the Safari controller using a fake DOM.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const ids = ['key','connectForm','connectPanel','loginError','network','connectionText','pulse',
'screen','empty','frameStats','connectBtn','disconnect','typingForm','remoteText','textStatus','textMode','sendText','fullscreenBtn'];
function el(id) {
  return { id, value:'', hidden:false, disabled:false, textContent:'', className:'', src:'',
    dataset:{}, style:{}, listeners:{}, classList:{toggle(){}},
    addEventListener(e, fn){this.listeners[e]=fn;},
    removeAttribute(name){delete this[name];},
    setPointerCapture(){}, getBoundingClientRect(){return {left:0,top:0,width:200,height:400};}
  };
}
const nodes = Object.fromEntries(ids.map(id=>[id,el(id)]));
const bodyClasses=new Set();
const bodyClassList={toggle(name){if(bodyClasses.has(name)){bodyClasses.delete(name);return false;} bodyClasses.add(name);return true;},remove(name){bodyClasses.delete(name);},contains(name){return bodyClasses.has(name);}};
nodes.fullscreenBtn.setAttribute=function(name,value){this[name]=value;};
nodes.fullscreenBtn.click=function(){this.listeners.click();};
const button = el('back'); button.dataset.action='back';
const callbacks=[]; const requests=[]; let count=0;
const sandbox = {
  document:{body:{classList:bodyClassList},getElementById(id){return nodes[id];},querySelectorAll(q){return q==='[data-action]'?[button]:[];},addEventListener(){}},
  URL:{createObjectURL(){return 'blob:test-'+(++count);},revokeObjectURL(){}},
  setTimeout(fn, delay){callbacks.push({fn,delay}); return callbacks.length;},
  clearTimeout(){},
  Date,Math,JSON,console,
  fetch:async (url, options) => {
    requests.push({url,options});
    if (url==='/login') return {status:200,ok:true,json:async()=>({session:'b'.repeat(64)})};
    if (url==='/frame' && requests.filter(r=>r.url==='/frame').length>1) {
      return {status:304,ok:false,headers:{get(){return null;}}};
    }
    if (url==='/frame') return {status:200,ok:true,blob:async()=>Buffer.from('jpeg'),headers:{get(k){return k==='ETag'?'"frame-1"':null;}}};
    return {status:200,ok:true};
  },
};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../android/app/src/main/assets/app.js'),'utf8'),sandbox);
function submit(id) {return nodes[id].listeners.submit({preventDefault(){}});}
function tick(){ const timer=callbacks.shift(); assert.ok(timer); timer.fn(); return timer.delay; }
(async()=>{
  assert.equal(nodes.sendText.disabled,true,'typing disabled before connection');
  nodes.key.value='a longer personal password!';
  await submit('connectForm');
  for(let i=0;i<5;i++) await new Promise(r=>setImmediate(r));
  assert.equal(nodes.sendText.disabled,false,'typing enabled when connected');
  assert.ok(requests.some(r=>r.url==='/frame'));
  assert.equal(JSON.parse(requests.find(r=>r.url==='/login').options.body).password,'a longer personal password!');
  assert.equal(requests.find(r=>r.url==='/frame').options.headers['X-Arunika-Session'],'b'.repeat(64));
  assert.ok(!requests.some(r=>JSON.stringify(r.options).includes('X-Arunika-Key')));
  assert.equal(tick(),220,'responsive frame polling');
  assert.equal(nodes.empty.hidden,true,'placeholder hidden after frame arrives');
  nodes.fullscreenBtn.listeners.click();
  assert.ok(bodyClasses.has('focus-mode'),'fullscreen mode enabled');
  nodes.fullscreenBtn.listeners.click();
  assert.ok(!bodyClasses.has('focus-mode'),'fullscreen mode exited');
  await new Promise(r=>setImmediate(r));
  assert.equal(requests.filter(r=>r.url==='/frame')[1].options.headers['If-None-Match'],'"frame-1"');
  nodes.remoteText.value='Halo dari iPhone!';
  nodes.textMode.value='replace';
  await submit('typingForm');
  const body=JSON.parse(requests.findLast(r=>r.url==='/action').options.body);
  assert.equal(body.action,'text');
  assert.equal(body.text,'Halo dari iPhone!');
  assert.equal(body.mode,'replace');
  nodes.screen.listeners.pointerdown({button:0,pointerId:5,clientX:100,clientY:200,preventDefault(){}});
  nodes.screen.listeners.pointerup({pointerId:5,clientX:100,clientY:200,preventDefault(){}});
  await new Promise(r=>setImmediate(r));
  assert.equal(JSON.parse(requests.findLast(r=>r.url==='/action').options.body).action,'tap');
  button.dataset.action='wake';
  await button.listeners.click();
  await new Promise(r=>setImmediate(r));
  assert.equal(JSON.parse(requests.findLast(r=>r.url==='/action').options.body).action,'wake');
  const css=fs.readFileSync(path.join(__dirname,'../android/app/src/main/assets/style.css'),'utf8');
  const html=fs.readFileSync(path.join(__dirname,'../android/app/src/main/assets/index.html'),'utf8');
  assert.match(css,/\[hidden\]\s*\{\s*display:\s*none\s*!important/, 'hidden state honored on Safari');
  assert.ok(html.indexOf('id="empty"')>html.indexOf('id="frameWrap"'), 'status moved beneath screen');
  assert.match(css,/aspect-ratio:9 \/ 19\.5/, 'phone aspect ratio');
  console.log('PASS: Safari full-width layout, focus toggle, password session, faster polling, ETag, text input, tap, wake');
})().catch(err=>{console.error(err);process.exit(1);});
