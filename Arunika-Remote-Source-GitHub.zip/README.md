# Arunika Remote v0.5 — Full Screen & Responsive

Prototipe pribadi untuk Redmi Note 10 Pro (Android 13 / MIUI 14) dan Safari iPhone lewat Tailscale.

## Perbaikan v0.5
- **Bug layar setengah lebar diperbaiki.** Di versi 0.4, elemen pesan “Menunggu tampilan Android” tetap mengambil lebar meskipun diberi atribut `hidden`. CSS kini memaksa `[hidden]` untuk benar-benar tersembunyi.
- Status koneksi dan pesan tunggu ditempatkan **di bawah gambar Android**, tidak lagi di sampingnya.
- Gambar Redmi memenuhi **seluruh lebar bingkai** (rasio layar portrait Android).
- Tombol **⛶ Layar penuh** untuk masuk mode fokus Safari. Tombol **✕ Tutup layar penuh** untuk kembali ke menu dan keyboard iPhone. Mode fokus bukan Safari Fullscreen API; toolbar Safari mungkin tetap terlihat.
- Pembaruan frame diperpendek dari 800 ms → **450 ms** di Android, dan interval pemeriksaan 350 ms → **220 ms** di Safari. Hasil sesungguhnya bergantung batas pengambilan screenshot Android/MIUI, CPU, dan latensi Tailscale.
- Fitur login password, bangunkan layar, ketik dari iPhone, dan batasan lock screen tetap sama dengan v0.4.

## Penting: ini **belum video live**
Mode v0.5 masih menggunakan screenshot berkala via `AccessibilityService.takeScreenshot`. Android membatasi frekuensi screenshot; **jangan mengharapkan 30/60 FPS**. `MediaProjection` + encoder H.264 + transport WebRTC adalah jalur untuk video live berlatensi rendah, tetapi mengharuskan persetujuan perekaman saat sesi dimulai dan uji kompatibilitas MIUI. Proyek ini belum menyertakan mode video.

## Build lewat GitHub Actions
1. Unggah `Arunika-Remote-Source-GitHub.zip` dari paket v0.5 ke root repository privat (ganti file lama, **jangan diekstrak**).
2. Perbarui `.github/workflows/build-apk.yml` menggunakan workflow dari paket yang sama.
3. Jalankan **Actions → Build Arunika Remote APK v0.5 → Run workflow** pada branch yang memuat ZIP terbaru.
4. Unduh artifact `Arunika-Remote-Fullscreen-v0.5-APK`, ekstrak `app-debug.apk`, lalu instal di Redmi.
5. Jika gagal memperbarui karena tanda tangan APK debug berbeda, uninstall versi sebelumnya mungkin diperlukan dan password/pengaturan Arunika harus dibuat ulang. Jangan hapus sebelum siap mengonfigurasi ulang.
6. Pastikan Play Protect tetap aktif, Tailscale berjalan di kedua HP, dan izin Aksesibilitas hanya diberikan setelah memverifikasi asal APK.
7. Buka Safari di iPhone dengan URL Tailscale Redmi, login memakai password Arunika yang kamu setel langsung di Redmi.

## Keamanan & keterbatasan
- Tidak bisa membuka kunci PIN/pola/biometrik Android. Screenshot dan kontrol tidak tersedia saat Android terkunci.
- Server hanya mengikat ke alamat IP Tailscale. Jangan dibuka ke internet umum.
- Source dan APK perlu audit sebelum digunakan pada perangkat dengan data sensitif. Tidak perlu menonaktifkan Play Protect.
- Build Android belum dijalankan dalam lingkungan penyusunan paket ini; jalankan via GitHub Actions untuk memeriksa kompilasi aktual.
