# Arunika Remote v0.4 — Password & Wake

> Prototipe untuk penggunaan pribadi di Redmi Note 10 Pro (MIUI 14, Android 13) + Safari iPhone melalui VPN Tailscale. Source disediakan untuk build **APK debug** di GitHub Actions. Aplikasi belum diuji langsung pada perangkat ini; wake screen bergantung kebijakan MIUI.

## Apa yang berubah dari v0.3

- Login Safari **cukup satu password** yang pengguna atur sendiri **di HP Redmi** lewat tombol **Atur / ganti password login**.
- Tidak ada kode acak 32 karakter untuk dimasukkan ke Safari. Jangan menuliskan password di source code, workflow, atau GitHub.
- Password Redmi disimpan sebagai PBKDF2-HMAC-SHA256 dengan salt acak (180.000 iterasi), bukan plaintext; saat login diberikan token sesi sementara yang hanya disimpan di memori.
- Sesi habis setelah 60 menit tidak digunakan atau ketika layanan Arunika dihentikan/diulang. Lima login gagal beruntun memicu jeda 15 menit.
- Safari menampilkan tombol **Bangunkan layar**. Ini hanya meminta layar Redmi menyala, **tidak dapat melewati PIN/pola/password/biometrik**.
- Jika lock screen muncul, remote sengaja tidak melayani screenshot/gesture/pengetikan sampai perangkat dibuka kuncinya oleh pemilik melalui metode Android yang sah.
- Peningkatan ke v0.4 membutuhkan pengaturan password baru di Redmi. Sesi/kode akses v0.3 tidak lagi digunakan.
- Komunikasi web menggunakan HTTP lokal **hanya** di alamat Tailscale IPv4 (100.64.0.0/10). Tunnel Tailscale mengenkripsi pengiriman antarperangkat. Jangan port-forward ke internet publik.

## Langkah memperbarui APK

1. Buat salinan file penting di HP. Jika tanda tangan APK debug berbeda dari versi sebelumnya, Android mungkin meminta uninstall dulu. Konfigurasi/izin aksesibilitas mungkin harus diatur ulang.
2. Upload `Arunika-Remote-Source-GitHub.zip` yang baru **tanpa diekstrak** ke root GitHub repository pribadi, menggantikan ZIP v0.3.
3. Letakkan `build-apk.yml` di `.github/workflows/build-apk.yml` lalu commit ke branch yang sama.
4. Buka GitHub → Actions → Build Arunika Remote APK v0.4 → Run workflow. Unduh APK di **Artifacts** dan ekstrak ZIP artifact untuk menemukan `app-debug.apk`.
5. Instal APK di Redmi. Biarkan Google Play Protect aktif; jangan berikan aksesibilitas sebelum memeriksa asal APK yang dipakai. Izinkan aksesibilitas, notifikasi, dan Tailscale jika sudah sesuai.
6. Buka Arunika di Redmi, tekan **Atur / ganti password login**, pilih password unik panjang (minimal 12 karakter). Hindari password yang pernah ditulis di chat atau yang mengandung nama pribadi.
7. Tekan **Aktifkan remote**. Cari alamat `http://100.x.y.z:18765` di aplikasi; buka URL ini di Safari iPhone saat Tailscale aktif.
8. Login dengan satu password. Tekan **Bangunkan layar** bila layar mati. Jika layar terkunci dengan PIN/pola/biometrik, Android tetap membutuhkan pemilik membuka kuncinya.

## Hal yang tetap dibatasi

- Ini bukan alat melewati keamanan Android. Tidak bisa membuka lock screen yang menggunakan PIN, pola, password, atau biometrik dari jarak jauh tanpa otorisasi sistem.
- Pada MIUI 14, layanan Aksesibilitas dan Tailscale bisa dimatikan oleh pengaturan baterai atau perangkat restart; lakukan uji sementara Redmi masih dalam jangkauan.
- `PowerManager.ACQUIRE_CAUSES_WAKEUP` deprecated pada Android 13; kemampuan wake di Redmi perlu diverifikasi.
- APK debug untuk percobaan pribadi, tidak untuk distribusi publik. Debug APK dan source perlu diaudit sebelum diberi akses ke data sensitif.
- Tidak ada Android SDK untuk build APK di lingkungan pembuatan paket ini. `node --check`, tes kontroler, sintaks workflow, dan integritas arsip dapat diperiksa, tetapi kompilasi Kotlin hanya diketahui saat GitHub Actions berjalan.
